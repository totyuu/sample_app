# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '25a8cff718c7a349901a8b5f0c50cea2a293a4cb8dd9d8fe60ba5f301d21702b41c2cc5951897387a7b7aa12eb90576f22a4ac5f77b2e1009313dd91aa530bb5'